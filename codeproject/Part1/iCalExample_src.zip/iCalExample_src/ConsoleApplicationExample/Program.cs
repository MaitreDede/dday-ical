using System;
using System.Collections.Generic;
using System.Text;

using DDay.iCal;
using DDay.iCal.Components;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            iCalendar iCal = iCalendar.LoadFromFile(@"Business.ics");

            //
            // Evaluate recurring events to determine if they will recur today
            //
            iCal.Evaluate(DateTime.Today, DateTime.Today.AddDays(1));

            Console.WriteLine("Today's Events:");

            // Iterate through each event we have to check if it occurs today
            foreach (Event evt in iCal.Events)
            {
                if (evt.OccursOn(DateTime.Today))
                    Console.WriteLine(evt.Summary + ": " + evt.Start.Local.ToShortTimeString());
            }

            //
            // Evaluate recurring events to determine if they will occur within the next 7 days
            //
            iCal.Evaluate(DateTime.Today, DateTime.Today.AddDays(7));

            Console.WriteLine("Upcoming Events:");

            // Start with tomorrow
            DateTime testDate = DateTime.Today.AddDays(1);
            while (testDate < DateTime.Today.AddDays(7))
            {
                foreach (Event evt in iCal.Events)
                {
                    if (evt.OccursOn(testDate))
                        Console.WriteLine(evt.Summary + ": " + evt.Start.Local.ToShortTimeString());
                }

                testDate = testDate.AddDays(1);
            }            
        }
    }
}
